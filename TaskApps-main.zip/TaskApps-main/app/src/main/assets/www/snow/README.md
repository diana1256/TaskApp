# Snow (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alphardex/pen/dyPorwJ](https://codepen.io/alphardex/pen/dyPorwJ).

Inspired by: https://codepen.io/YusukeNakaya/pen/NWPqvWW

This is a pure CSS version :d

